This directory will contain the parser implementation (e.g. Parser.hpp/cpp, grammar-driven parsing code).

Place parser sources here when implementing syntax analysis.
