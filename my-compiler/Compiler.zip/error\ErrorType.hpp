#pragma once

enum class ErrorType {
    ILLEGAL_SYMBOL,
};
