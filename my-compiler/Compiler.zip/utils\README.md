This directory will contain utility code used across the compiler (I/O helpers, common data structures, debug utilities).

Examples: IOHandler.hpp/cpp, Debug.hpp, Settings.hpp.
