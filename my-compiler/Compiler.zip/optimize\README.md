This directory will contain optimization passes and utilities (e.g. CFG builder, register allocator).

Place optimization-related files here.
