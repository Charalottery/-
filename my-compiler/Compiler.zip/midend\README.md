This directory will contain mid-end components (IR generation, optimizations, and transformations).

Possible files: MidEnd.hpp/cpp, IRBuilder, passes, etc.
