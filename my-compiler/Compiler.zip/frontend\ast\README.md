This directory will contain AST node definitions and utilities (e.g. AstNode.hpp, AstVisitor.hpp).

Use this folder to model the abstract syntax tree for the compiler.
