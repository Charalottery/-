This directory will contain backend components (code generation, target-specific emitters).

Examples: Backend.hpp/cpp, codegen for x86/mips/llvm.
