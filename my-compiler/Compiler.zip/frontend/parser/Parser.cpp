#include "Parser.hpp"
#include "../ast/Node.hpp"
#include <memory>

Parser::Parser() : tokenStream(std::vector<Token>()), rootNode(nullptr) {}

void Parser::SetTokenStream(TokenStream stream) {
    this->tokenStream = std::move(stream);
}

void Parser::GenerateAstTree() {
    // Wire token stream into Node static access (similar to Java example)
    Node::SetTokenStream(&this->tokenStream);
    this->rootNode = new CompUnit();
    this->rootNode->Parse();
}

CompUnit* Parser::GetAstTree() { return this->rootNode; }
