#pragma once

#include "../lexer/TokenStream.hpp"
#include "../ast/CompUnit.hpp"

class Parser {
public:
    Parser();

    void SetTokenStream(TokenStream stream);
    void GenerateAstTree();
    CompUnit* GetAstTree();

private:
    TokenStream tokenStream;
    CompUnit* rootNode;
};
