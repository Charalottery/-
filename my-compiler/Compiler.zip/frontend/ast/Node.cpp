#include "Node.hpp"

TokenStream* Node::tokenStream = nullptr;
